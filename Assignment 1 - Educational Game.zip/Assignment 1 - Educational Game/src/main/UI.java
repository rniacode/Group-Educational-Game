package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class UI implements MouseListener {

    GameManager gm;
    JFrame window;
    JTextArea messageText;
    JLabel submitBox;
    JLabel[] answerLabels = new JLabel[3];
    
//  number of backgrounds (10)
    JPanel bgPanel[] = new JPanel[10];
    JLabel bgLabel[] = new JLabel[10];

    public UI(GameManager gm) {
        this.gm = gm;
        createMainField();
        generateScreen();
        window.setVisible(true);
    }

    public void createMainField() {
        window = new JFrame();
        window.setSize(800, 600);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.getContentPane().setBackground(Color.black);
        window.setLayout(null);

        messageText = new JTextArea("There are hidden clues which uncovers questions related to Brunei. Find them!");
        
//      (x, y, width, height)
        messageText.setBounds(50, 410, 700, 50);
        messageText.setBackground(Color.black);
        messageText.setForeground(Color.white);
        messageText.setEditable(false);
        messageText.setLineWrap(true);
        messageText.setWrapStyleWord(true);
        
//      (Font, Font Style, Font Size)
        messageText.setFont(new Font("Consolas", Font.PLAIN, 20));
        window.add(messageText);
        
     // Initialize submitBox
        submitBox = new JLabel("Submit");
        submitBox.setBounds(600, 500, 150, 40);
        submitBox.setBackground(Color.gray);
        submitBox.setForeground(Color.white);
        submitBox.setOpaque(true);
        submitBox.setHorizontalAlignment(JLabel.CENTER);
        submitBox.setFont(new Font("Consolas", Font.PLAIN, 17));
        submitBox.addMouseListener(this);
        window.add(submitBox);
        
     // Initialize answerLabels
        String[] answers = {"Jerudong Park", "Royal Regalia Museum", "Ulu Temburong National Park"};
        for (int i = 0; i < answerLabels.length; i++) {
            answerLabels[i] = new JLabel((i + 1) + ") " + answers[i]);
            answerLabels[i].setBounds(50, 460 + (i * 30), 700, 30); // Adjusted y-coordinate
            answerLabels[i].setBackground(Color.black);
            answerLabels[i].setForeground(Color.white);
            answerLabels[i].setFont(new Font("Consolas", Font.PLAIN, 20));
            answerLabels[i].setOpaque(true);
            answerLabels[i].setHorizontalAlignment(JLabel.LEFT);
            answerLabels[i].addMouseListener(this);
            window.add(answerLabels[i]);
        }
    }

    public void createBackground(int bgNum, String bgFileName) {
        bgPanel[bgNum] = new JPanel();
        
        // (x, y, width, height)
        bgPanel[bgNum].setBounds(50, 50, 700, 350);
        bgPanel[bgNum].setBackground(Color.blue);
        bgPanel[bgNum].setLayout(null);
        bgPanel[bgNum].addMouseListener(this);
        
        // Add panel to the window        
        window.add(bgPanel[bgNum]);
        
     // Create and configure the label for the background image
        bgLabel[bgNum] = new JLabel();
        bgLabel[bgNum].setBounds(0, 0, 700, 350);
        
     // Load the background image
        ImageIcon bgIcon = new ImageIcon(getClass().getClassLoader().getResource(bgFileName));
        bgLabel[bgNum].setIcon(bgIcon);
        bgPanel[bgNum].add(bgLabel[bgNum]);
    }
    
//  public void createObject(int bgNum, int objx, intobjy, int objWidth, int objHeight, String objFileName) {
//  
//  JLabel objectLabel = new JLabel();
//  objectLabel.setBounds(objx, objy objWidth, objHeight);
//  
//  ImageIcon objectIcon = new ImageIcon(getClass().getClassLoader().getResource(objFileName));
//  objectLabel.setIcon(objectIcon);
//}

    public void generateScreen() {
        createBackground(1, "left side of classroom.png");
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();

        // Define the coordinates of the clickable area
        int clickableAreaX = 200;
        int clickableAreaY = 100;
        int clickableAreaWidth = 200;
        int clickableAreaHeight = 100;

        // Check if the click occurred within the clickable area
        if (x >= clickableAreaX && x <= clickableAreaX + clickableAreaWidth &&
            y >= clickableAreaY && y <= clickableAreaY + clickableAreaHeight) {
            // Perform the action when the clickable area is clicked
            messageText.setText("What is this Brunei attraction called?");
        }
        
        Object source = e.getSource();
        if (source == submitBox) {
            messageText.setText("Submit button clicked!");
        } else {
            // Check which answer label was clicked
            for (int i = 0; i < answerLabels.length; i++) {
                if (source == answerLabels[i]) {
                    checkAnswer(i);
                    break;
                }
            }
        }
    }
    
    private void checkAnswer(int answerIndex) {
        // Check if the answer is correct (sample logic)
        boolean isCorrect = answerIndex == 0; // Sample: answer 1 is correct
        
        // Display appropriate message
        if (isCorrect) {
            messageText.setText("Correct!");
        } else {
            messageText.setText("Incorrect answer!");
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // Not used in this example
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // Not used in this example
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // Not used in this example
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Not used in this example
    }
}










